class LogoutPage {
  elements = {
    logoutBtn: () => cy.get("#root > div > header > div > div > span > button"),
    logoutLink: () => cy.get("ul > li > div.MuiListItemText-root > span"),
  };

  clickLogoutBtn() {
    this.elements.logoutBtn().click({ force: true });
  }

  clickLogoutLink() {
    this.elements.logoutLink().click({ force: true });
  }
}
export default LogoutPage;
