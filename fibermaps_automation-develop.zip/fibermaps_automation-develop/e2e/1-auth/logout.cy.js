import LogoutPage from "../../POM/pages/LogoutPage";
import LoginPage from "../../POM/pages/LoginPage";

const logoutPage = new LogoutPage();
const loginPage = new LoginPage();

describe("Logout", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("AUTH_01 , should allow logout when click the logout button and go to login page", () => {
    loginPage.fillUserName(Cypress.env("username"));
    loginPage.fillPassword(Cypress.env("password"));
    loginPage.clickLoginBtn();

    //click the logout button
    logoutPage.clickLogoutBtn();
    logoutPage.clickLogoutLink();
  });
});
