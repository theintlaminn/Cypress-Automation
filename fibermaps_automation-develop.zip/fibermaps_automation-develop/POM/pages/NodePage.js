class NodePage {
  elements = {
    nodeAddBtn: () => cy.get('button[title="Add Node"]'),
    csvUploadBtn: () => cy.get('button[title="Upload CSV"'),
    csvDownloadBtn: () => cy.get('button[title="Download CSV Template"'),
    nodeInvalidMsg: () => cy.get("#name-helper-text"),
    nodeErrMsg: () => cy.get(".MuiAlert-message"),
    //edit node
    nodeEditBtn: () => cy.get('button[title="Update Node"]'),
    nodeDeleteBtn: () => cy.get('button[title="Delete Node"]'),
    edgeLinkBtn: () => cy.get('button[title="Link"'),
    //Cancel and Submit btn
    cancelBtn: () => cy.get(":nth-child(1) > .MuiButton-label"),
    submitConfirmBtn: () => cy.get(":nth-child(2) > .MuiButton-label"),
    //Searching Node
    searchBox: () => cy.get('input[placeholder="Search"]'),
    nodeTable: () => cy.get(".MuiTable-root"),
    nodeRow: () => cy.get("tr:nth-child(2)"),
    nodeTd: () => cy.get("td:nth-child(1)"),
    nodeNameInTableFirstRow: () =>
      cy.get("table > tbody > tr:nth-child(2) > td:nth-child(1)"),
  };

  form = {
    //for create node
    nodeNameTxt: () => cy.get("#name"),
    townshipTxt: () => cy.get("#township"),
    //township option
    townshipOption: () => cy.get("#township-option-67"),
    townshipClearBtn: () =>
      cy.get("form>div:nth-child(2)>div>div>div>button:nth-child(1)"),
    descTxt: () => cy.get("#desc"),
    //tag
    tagsMulSelect: () => cy.get("#tags"),
    terminatedOption: () => cy.get("#tags-option-0"),
    //for device type and device type option
    deviceTypeSelect: () => cy.get("#device_type"),
    //for connection type
    connectionTypeTxt: () => cy.get("#connection_type"),
    connectionTypeClearBtn: () =>
      cy.get("form>div:nth-child(6)>div>div>div>button:nth-child(1)"),
    connectionTypePencilKit: () => cy.get("#connection_type-option-0"),
    //for max port
    oltMaxportTxt: () =>
      cy.get(":nth-child(8) > .MuiInputBase-root > .MuiInputBase-input"),
    //CA1 CA2 and OTB with box key text fields
    ca1MaxportTxt: () =>
      cy.get(":nth-child(9) > .MuiInputBase-root > .MuiInputBase-input"),
    //CA2 and OTB with box key text fields
    boxMaxportTxt: () =>
      cy.get(":nth-child(10) > .MuiInputBase-root > .MuiInputBase-input"),
    cpeMaxportTxt: () =>
      cy.get(":nth-child(7) > .MuiInputBase-root > .MuiInputBase-input"),
    ftsbsMaxportTxt: () =>
      cy.get(":nth-child(8) > .MuiInputBase-root > .MuiInputBase-input"),
    //For only CPE device type
    cpeUplinkTxt: () => cy.get("form>div:nth-child(8)>div>input"),
    ftsbsUplinkTxt: () => cy.get("form>div:nth-child(9)>div>input"),
    ca1UplinkTxt: () => cy.get("form>div:nth-child(10)>div>input"),
    //CA2 and OTB uplink box
    boxUplinkTxt: () => cy.get("form>div:nth-child(11)>div>input"),
    //when choice other device this input field will display
    latTxt: () => cy.get(":nth-child(4) > .MuiInputBase-root > #name"),
    longTxt: () => cy.get(":nth-child(5) > .MuiInputBase-root > #name"),
    boxKeyTxt: () => cy.get("#box_key"),
    boxTypeSelect: () => cy.get("#box_type"),
  };

  successMessage = {
    createMsg: "Successfully created!",
    editMsg: "Successfully edited!",
    deleteMsg: "Successfully deleted",
    uploadMsg: "Upload file successfull!",
  };

  errorMessage = {
    nodeInvalidFormat: "Invalid node name format!",
    nodeNameInvalid: '"Node name is invalid"',

    // childNodeExitMsg: "Child nodes exist",
    nodeExistMsg: '"Node already exists. "',
    CpeNameExistMsg: '"CPE name already existed. "',
    cpeNamePortExistMessage:
      '"Node already exists. CPE name already existed. "',

    // srcNodeNotFoundMeg: "Source node doesn't found",
    uplinkNoFoundMsg: '"Uplink Node Not Found"',

    portNotFreeMessage: '"Port is already used"',
    // portRangeExceedMessage: "Port out of range",
    // cpeMaxPortErrMsg: '"Max Ports Reached"',
    maxPortInvalidMsg: "Invalid Max Port Value!",
    parentPortInsuficientMsg:
      "\"Parent node's used port is greater than parent node's max ports. \"",

    invalidLatLongMsg: "Invalid lat long format!",
    emptyLatLongMsg:
      "Invalid lat long format! lat long must be between 12 and 26",

    wrongCA1uplinkName: '"CA1 Uplink Should be OLT"',
    wrongCA2uplinkName: '"CA2 Uplink Node Should be CA1"',
    wrongOTBuplinkName: '"OTB Uplink Node Should be CA2"',
    wrongFT_SBSuplinkName: '"CPE uplink should be CA2 or OTB. "',
    //blur alert message
    uplinkNodeBlurMsg: "Enter Uplink Node!",
    townshipBlurMsg: "Enter Township Value!",
    connectionTypeBlurMsg: '"Cable type must be provided. "',
  };

  // CLICK EVENT FUNC:

  // clickUploadBtn() {
  //   this.elements.csvUploadBtn().click();
  // }

  // clickDownloadBtn() {
  //   this.elements.csvDownloadBtn().click();
  // }

  // clickLinkEdgeBtn() {
  //   this.elements.edgeLinkBtn().click();
  // }

  clickNodeAddBtn() {
    this.elements.nodeAddBtn().click({ force: true });
  }

  // clickEditNodeBtn() {
  //   this.elements.nodeEditBtn().click();
  // }

  // clickDeleteNodeBtn() {
  //   this.elements.nodeDeleteBtn().click();
  // }

  clickcancelBtn() {
    this.elements.cancelBtn().click();
  }

  clicksubmitBtn() {
    this.elements.submitConfirmBtn().click({ force: true });
  }

  // CLEAR DATA FUNC:
  clearNodeName() {
    this.form.nodeNameTxt().clear();
  }

  clearTownship() {
    this.form.townshipClearBtn().click({ force: true });
  }

  clearConnectionType() {
    this.form.connectionTypeClearBtn().click({ force: true });
  }

  clearFtsbsUplink() {
    this.form.ftsbsUplinkTxt().clear();
  }

  clearBoxMaxPort() {
    this.form.boxMaxportTxt().clear({ force: true });
  }

  clearLatitude() {
    this.form.latTxt().clear();
  }

  clearLongitude() {
    this.form.longTxt().clear();
  }

  // DROP DOWN CHOOSE
  chooseTownship() {
    this.form.townshipTxt().click();
    this.form.townshipOption().click();
  }

  chooseTag() {
    this.form.tagsMulSelect().click();
    this.form.terminatedOption().click();
  }

  chooseOLTDeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(4);
  }

  chooseCA1DeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(1);
  }

  chooseCA2DeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(2);
  }

  chooseOTBDeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(3);
  }

  chooseCPEDeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(0);
  }

  chooseFTSBSDeviceType() {
    this.form.deviceTypeSelect().scrollIntoView().select(5);
  }

  chooseConnectionType() {
    this.form.connectionTypeTxt().click();
    this.form.connectionTypePencilKit().click();
  }

  chooseBoxType() {
    this.form.boxTypeSelect().scrollIntoView().select(1);
  }

  // FILL TEXT
  fillSearchKeyword(keyword) {
    this.elements.searchBox().scrollIntoView();
    this.elements.searchBox().clear({ force: true });
    this.elements.searchBox().type(keyword, { force: true });
  }

  fillNodeName(nodeNameTxt) {
    this.clearNodeName();
    this.form.nodeNameTxt().type(nodeNameTxt);
  }

  fillDescription(descTxt) {
    this.form.descTxt().clear({ force: true });
    this.form.descTxt().type(descTxt, { force: true });
  }

  fillLatitude(latTxt) {
    this.clearLatitude();
    this.form.latTxt().type(latTxt);
  }

  fillLongitude(longTxt) {
    this.clearLongitude();
    this.form.longTxt().type(longTxt);
  }

  fillOLTMaxPort(maxport) {
    this.form.oltMaxportTxt().click();
    this.form.oltMaxportTxt().clear({ force: true });
    this.form.oltMaxportTxt().type(maxport, { force: true });
  }

  fillCA1MaxPort(maxport) {
    this.form.ca1MaxportTxt().click();
    this.form.ca1MaxportTxt().clear({ force: true });
    this.form.ca1MaxportTxt().type(maxport, { force: true });
  }

  fillBoxMaxPort(maxport) {
    this.form.boxMaxportTxt().click();
    this.clearBoxMaxPort();
    this.form.boxMaxportTxt().type(maxport, { force: true });
  }

  fillCPEMaxPort(maxport) {
    this.form.cpeMaxportTxt().click();
    this.form.cpeMaxportTxt().clear({ force: true });
    this.form.cpeMaxportTxt().type(maxport, { force: true });
  }

  fillFTSBSMaxPort(maxport) {
    this.form.ftsbsMaxportTxt().click();
    this.form.ftsbsMaxportTxt().clear({ force: true });
    this.form.ftsbsMaxportTxt().type(maxport, { force: true });
  }

  fillCA1Uplink(uplink) {
    this.form.ca1UplinkTxt().clear();
    this.form.ca1UplinkTxt().type(uplink);
  }

  fillBoxUplink(uplink) {
    this.form.boxUplinkTxt().clear();
    this.form.boxUplinkTxt().type(uplink);
  }

  fillCPEUplink(uplink) {
    this.form.cpeUplinkTxt().clear();
    this.form.cpeUplinkTxt().type(uplink);
  }

  fillFTSBSUplink(uplink) {
    this.clearFtsbsUplink();
    this.form.ftsbsUplinkTxt().type(uplink);
  }

  fillBoxKey(boxKeyTxt) {
    this.form.boxKeyTxt().clear();
    this.form.boxKeyTxt().type(boxKeyTxt);
  }
}
export default NodePage;
