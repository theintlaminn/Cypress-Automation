import NodePage from "../../POM/pages/NodePage";
import SideBar from "../../POM/nav/SideBar";

const nodePage = new NodePage();
const sideBar = new SideBar();

describe("Create Nodes", () => {
  before(() => {
    cy.login(Cypress.env("username"), Cypress.env("password"));
  });

  beforeEach(() => {
    cy.visit("/");
    sideBar.clickNodesMenuIcon();
  });

  after(() => {
    cy.logout();
  });

  // check node create positive case

  it("ND_CREATE_1_1, OLT creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_olt"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(Cypress.env("olt_max_port"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_olt")
      );
    });
  });

  it("ND_CREATE_1_2_1, CA1 creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_ca1"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_ca1")
      );
    });
  });

  it("ND_CREATE_1_2_2, CA2 creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_ca2"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_ca2")
      );
    });
  });

  it("ND_CREATE_1_2_3, OTB creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_otb"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_otb")
      );
    });
  });

  it("ND_CREATE_1_3 , CPE creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_cpe"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.chooseConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_cpe")
      );
    });
  });

  it("ND_CREATE_1_4 , FT-SBS creation should success with valid data inputs", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pos_case_ftsbs"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillFTSBSUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    cy.wait(5000);
    nodePage.elements.nodeNameInTableFirstRow().then(($nodeName) => {
      expect($nodeName.text().trim()).to.equal(
        Cypress.env("nd_create_pos_case_ftsbs")
      );
    });
  });

  // check the node name format with error message

  it("ND_CREATE_3_1, OLT creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_olt_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(Cypress.env("olt_max_port"));
    nodePage.clicksubmitBtn();

    //check OLT invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_2 , CA1 creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_ca1_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check the CA1 invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_3 , CA2 creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_ca2_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check the CA2 invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_4 , OTB creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_otb_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the OTB invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_5 , FT-SBS creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_ftsbs_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillFTSBSUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the FT-SBS invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_6 , CPE creation should fail when an invalid name is used", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("invalid_cpe_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.chooseConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the CPE invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_3_7, OTB creation should fails when prefix name is different from it's parent CA2 name", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_otb_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeNameInvalid
        );
      });
  });

  // check for require fields and its format

  it("ND_CREATE_4_1 ,node creation should fails when the latlong format is incorrect", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_olt_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("invalid_lat"));
    nodePage.fillLongitude(Cypress.env("invalid_long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(Cypress.env("olt_max_port"));

    //check the latlong invalid format error message
    nodePage.elements
      .nodeInvalidMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.invalidLatLongMsg
        );
      });
  });

  it("ND_CREATE_4_2 , OLT creation should fails when the maxport value is '0'", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_olt_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(0);
    nodePage.clicksubmitBtn();

    //check the max port invalid format error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.maxPortInvalidMsg
        );
      });
  });

  it("ND_CREATE_2_1 ,  OLT creation should fail when node name is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.clearNodeName();
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(Cypress.env("olt_max_port"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeInvalidFormat
        );
      });
  });

  it("ND_CREATE_2_2_1 , CA1 creation should fail when township code is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ca1_name"));
    nodePage.clearTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.townshipBlurMsg
        );
      });
  });

  it("ND_CREATE_2_2_2, CA2 creation should fail when latlong is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ca2_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.chooseTag();
    nodePage.clearLatitude();
    nodePage.clearLongitude();
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.emptyLatLongMsg
        );
      });
  });

  it("ND_CREATE_2_2_3 , OTB creation should fail when max port is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_otb_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.clearBoxMaxPort();
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.maxPortInvalidMsg
        );
      });
  });

  it("ND_CREATE_2_2_4, FT-SBS creation should fail when the uplink is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ftsbs_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.clearFtsbsUplink();
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.uplinkNodeBlurMsg
        );
      });
  });

  it("ND_CREATE_2_3, CPE creation should fail when connection type is empty", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_cpe_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.clearConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.connectionTypeBlurMsg
        );
      });
  });

  //check the uplink Hierarchy wrong case

  it("ND_CREATE_5_1_1 , CA1 creation should fail when uplink node doesn't follow hierarchy rule", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ca1_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.wrongCA1uplinkName
        );
      });
  });

  it("ND_CREATE_5_1_2 , CA2 creation should fail when uplink doesn't follow hierarchy rule", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ca2_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.wrongCA2uplinkName
        );
      });
  });

  it("ND_CREATE_5_1_3 , OTB creation should fail when uplink doesn't follow hierarchy rule", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_otb_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.wrongOTBuplinkName
        );
      });
  });

  it("ND_CREATE_5_1_4 , FT-SBS creation should fail when uplink doesn't follow hierarchy rule", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ftsbs_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillFTSBSUplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.wrongFT_SBSuplinkName
        );
      });
  });

  it("ND_CREATE_5_1_5 , CPE creation should fail when uplink doesn't follow hierarchy rule", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_cpe_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.chooseConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.wrongFT_SBSuplinkName
        );
      });
  });

  //check uplink node haven't in the system

  it("ND_CREATE_5_2 , CA1 creation should fail when uplink node doesn't have in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_ca1_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("neg_case_olt_name"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.uplinkNoFoundMsg
        );
      });
  });

  // //Verify duplicate node cannot be created

  it("ND_CREATE_6_1_1 , OLT creation should fail when olt name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_olt"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOLTDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillOLTMaxPort(Cypress.env("olt_max_port"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeExistMsg
        );
      });
  });

  it("ND_CREATE_6_1_2 , CA1 creation should fail when CA1 name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeExistMsg
        );
      });
  });

  it("ND_CREATE_6_1_3 , CA2 creation should fail when CA2 name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeExistMsg
        );
      });
  });

  it("ND_CREATE_6_1_4 , OTB creation should fail when OTB name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_otb"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeExistMsg
        );
      });
  });

  it("ND_CREATE_6_1_5 , FT-SBS creation should fail when FT-SBS name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_ftsbs"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillFTSBSUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.cpeNamePortExistMessage
        );
      });
  });

  it("ND_CREATE_6_2 , CPE creation should fail when port+cpe name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("nd_create_pre_define_cpe"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.chooseConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_otb"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.cpeNamePortExistMessage
        );
      });
  });

  it("ND_CREATE_6_3 , CPE creation should fail when CID name is already exists in system", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("cid_only_duplidate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.chooseConnectionType();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_otb"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.CpeNameExistMsg
        );
      });
  });

  it("ND_CREATE_7_1_1 , CA1 creation should fail when it's port is already exists in their parent node", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("ca1_port_duplicate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA1DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.fillCA1MaxPort(Cypress.env("ca1_max_port"));
    nodePage.fillCA1Uplink(Cypress.env("nd_create_pre_define_olt"));
    nodePage.clicksubmitBtn();

    //check the error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.portNotFreeMessage
        );
      });
  });

  it("ND_CREATE_7_1_2 , CA2 creation should fail when it's port is already exists in their parent node", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("ca2_port_duplicate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseCA2DeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("ca2_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca1"));
    nodePage.clicksubmitBtn();

    //check the error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.portNotFreeMessage
        );
      });
  });

  it("ND_CREATE_7_1_3 , OTB creation should fail when it's port is already exists in their parent node", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("otb_port_duplicate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.nodeNameInvalid
        );
      });
  });

  it("ND_CREATE_7_1_4 , CPE creation should fail when it's port is already exists in their parent node", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("cpe_port_duplicate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseTag();
    nodePage.fillCPEMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillCPEUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.portNotFreeMessage
        );
      });
  });

  it("ND_CREATE_7_1_5 , FT-SBS creation should fail when it's port is already exists in their parent node", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("ftsbs_port_duplicate_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseFTSBSDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.chooseTag();
    nodePage.fillFTSBSMaxPort(Cypress.env("cpe_ftsbs_max_port"));
    nodePage.fillFTSBSUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check the error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.portNotFreeMessage
        );
      });
  });

  it("ND_CREATE_8_1 , OTB creation should fail when OTB's max port is greater its parent's max port", () => {
    nodePage.clickNodeAddBtn();
    nodePage.fillNodeName(Cypress.env("neg_case_otb_name"));
    nodePage.chooseTownship();
    nodePage.fillDescription(Cypress.env("description"));
    nodePage.chooseOTBDeviceType();
    nodePage.fillLatitude(Cypress.env("lat"));
    nodePage.fillLongitude(Cypress.env("long"));
    nodePage.fillBoxKey(Cypress.env("box_key"));
    nodePage.chooseTag();
    nodePage.chooseBoxType();
    nodePage.fillBoxMaxPort(Cypress.env("invalid_otb_max_port"));
    nodePage.fillBoxUplink(Cypress.env("nd_create_pre_define_ca2"));
    nodePage.clicksubmitBtn();

    //check error message
    nodePage.elements
      .nodeErrMsg()
      .should("be.visible")
      .then(($message) => {
        expect($message.text().trim()).to.equal(
          nodePage.errorMessage.parentPortInsuficientMsg
        );
      });
  });
});
