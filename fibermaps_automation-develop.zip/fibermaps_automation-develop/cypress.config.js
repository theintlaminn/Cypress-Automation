const { defineConfig } = require("cypress");

module.exports = defineConfig({
  downloadsFolder: "./downloads",
  fixturesFolder: "./fixtures",
  screenshotsFolder: "./screenshots",
  videosFolder: "./videos",
  e2e: {
    defaultCommandTimeout: 10000,
    baseUrl: "https://fibermaps-qa.frontiir.net/",
    specPattern: "./e2e/**/*.cy.{js,jsx,ts,tsx}",
    supportFile: "./support/e2e.js",
    testIsolation: false,
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
  },
});
