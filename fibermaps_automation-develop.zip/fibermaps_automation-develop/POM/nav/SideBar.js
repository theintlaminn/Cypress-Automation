class SideBar {
  elements = {
    townshipMenuIcon: () => cy.get(".MuiList-root a:nth-child(2)"),
    tagsMenuIcon: () => cy.get(".MuiList-root a:nth-child(3)"),
    nodeMenuIcon: () => cy.get(".MuiList-root a:nth-child(4)"),
    edgeMenuIcon: () => cy.get(".MuiList-root a:nth-child(5)"),
    hierarchyMenuIcon: () => cy.get(".MuiList-root a:nth-child(6)"),
    uploadHistoryMenuIcon: () => cy.get(".MuiList-root a:nth-child(7)"),
    auditLogMenuIcon: () => cy.get(".MuiList-root a:nth-child(8)"),
    reportMenuIcon: () => cy.get(".MuiList-root a:nth-child(9)"),
    systemManageMenuIcon: () => cy.get(".MuiList-root a:nth-child(10)"),
  };

  //Actions
  clickTownshipMenuIcon() {
    this.elements.townshipMenuIcon().click();
  }

  clickTagsMenuIcon() {
    this.elements.tagsMenuIcon().click();
  }

  clickNodesMenuIcon() {
    this.elements.nodeMenuIcon().click();
  }

  clickEdgesMenuIcon() {
    this.elements.edgeMenuIcon().click();
  }

  clickHierarchyMenuIcon() {
    this.elements.hierarchyMenuIcon().click();
  }

  clickUploadHistoryMenuIcon() {
    this.elements.uploadHistoryMenuIcon().click();
  }

  clickAuditLogMenuIcon() {
    this.elements.auditLogMenuIcon().click();
  }

  clickReportMenuIcon() {
    this.elements.reportMenuIcon().click();
  }

  clickSystemManageMenuIcon() {
    this.elements.systemManageMenuIcon().click();
  }
}
export default SideBar;
