import LoginPage from "../../POM/pages/LoginPage";
import NavBar from "../../POM/nav/NavBar";

const loginPage = new LoginPage();
const navBar = new NavBar();

describe("Login", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("should allow login with valid credentials", () => {
    loginPage.fillUserName(Cypress.env("username"));
    loginPage.fillPassword(Cypress.env("password"));
    loginPage.clickLoginBtn();
    //check nav bar text
    navBar.elements.navTitle().should("have.text", navBar.texts.navTitle);
  });

  it("should fail login and display error message for invalid credentials", () => {
    loginPage.fillUserName("invalid_user");
    loginPage.fillPassword("invalid_password");
    loginPage.clickLoginBtn();
    // check login fail error message
    loginPage.elements
      .errorMsg()
      .should("have.text", loginPage.messages.loginErrMsg);
  });
});
