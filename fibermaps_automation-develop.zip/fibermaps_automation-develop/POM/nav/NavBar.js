class NavBar {
  elements = {
    navTitle: () => cy.get("header .MuiToolbar-root h6"),
  };

  texts = {
    navTitle: "Passive Optical Network Data",
  };
}
export default NavBar;
