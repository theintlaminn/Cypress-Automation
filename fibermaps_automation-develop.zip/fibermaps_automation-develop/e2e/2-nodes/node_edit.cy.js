import NodePage from "../../POM/pages/NodePage";
import SideBar from "../../POM/nav/SideBar";

const nodePage = new NodePage();
const sideBar = new SideBar();

describe("Create Nodes", () => {
  before(() => {
    cy.login(Cypress.env("username"), Cypress.env("password"));
  });

  beforeEach(() => {
    cy.visit("/");
    sideBar.clickNodesMenuIcon();
  });

  after(() => {
    cy.logout();
  });
});
