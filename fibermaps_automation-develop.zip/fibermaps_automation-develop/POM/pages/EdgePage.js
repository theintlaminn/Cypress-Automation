class EdgePage {
  elements = {};

  form = {};

  messages = {};
}
export default EdgePage;
