class LoginPage {
  elements = {
    userName: () => cy.get("#username"),
    password: () => cy.get("#password"),
    loginBtn: () => cy.get("#kc-form-buttons"),
    errorMsg: () => cy.get("#input-error"),
  };

  messages = {
    loginErrMsg: "Invalid username or password.",
  };

  fillUserName(userName) {
    this.elements.userName().clear();
    this.elements.userName().type(userName);
  }

  fillPassword(password) {
    this.elements.password().clear();
    this.elements.password().type(password);
  }

  clickLoginBtn() {
    this.elements.loginBtn().click();
  }

  clickLogoutBtn() {
    this.elements.logoutBtn().click();
  }
}
export default LoginPage;
