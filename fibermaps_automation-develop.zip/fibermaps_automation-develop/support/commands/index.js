import "../commands/auth";

Cypress.on("uncaught:exception", (err, runnable) => {
  // returning false here prevents Cypress from failing the test
  if (err.message.includes("oe.filter is not a function")) {
    return false;
  }
});
