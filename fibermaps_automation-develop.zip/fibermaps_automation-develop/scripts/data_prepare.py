import structlog
import json
import os
from db_connection import get_db_connection
from clear_test_data import remove_all
from create_test_data import add_all
from dotenv import load_dotenv

load_dotenv()

log = structlog.get_logger()

db = get_db_connection()

# Delete all test data
remove_all(db)
# Add test data for node create spec
print("-----------Create Data for Node Create Test-----------")
add_all(db,os.getenv("ND_CREATE_NODE_FILE"),os.getenv("ND_CREATE_EDGE_FILE"),os.getenv("ND_CREATE_GRAPH_FILE"))
# Add test data for node edit spec
print("-----------Create Data for Node Edit Test-----------")
add_all(db,os.getenv("ND_EDIT_NODE_FILE"),os.getenv("ND_EDIT_EDGE_FILE"),os.getenv("ND_EDIT_GRAPH_FILE"))


