import os
from dotenv import load_dotenv
from urllib.parse import quote_plus
from pymongo import MongoClient

load_dotenv()

def get_db_connection():
    DB_HOST = os.getenv("DB_HOST")
    DB_PORT = os.getenv("DB_PORT")
    DB_NAME = os.getenv("DB_NAME")
    DB_USER = os.getenv("DB_USER")
    DB_PASSWORD = os.getenv("DB_PASSWORD")

    database = f"{DB_HOST}:{DB_PORT}/{DB_NAME}"
    authentication = f"{quote_plus(DB_USER)}:{quote_plus(DB_PASSWORD)}"
    uri = f"mongodb://{authentication}@{database}"

    client = MongoClient(uri)
    db = client[DB_NAME]

    return db










