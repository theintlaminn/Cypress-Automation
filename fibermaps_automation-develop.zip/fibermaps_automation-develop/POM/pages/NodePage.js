class NodePage {
  elements = {};

  form = {};

  messages = {};
}
export default NodePage;
