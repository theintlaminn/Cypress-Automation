import structlog
import json

log = structlog.get_logger()

def add_all(db,node_file,edge_file,graph_file):
    print("-----------Create Graph Start-----------")
    # CREATE TEST DATA
    # create graph
    with open(graph_file,'r') as openfile:
        graph = json.load(openfile)
        graph_query_result = db.graph.insert_one(graph)
        log.debug("Graph inserted id : %s ",graph_query_result.inserted_id)

    print("-----------Create Node Start-----------")
    # create node
    with open(node_file,'r') as openfile:
        node_obj = json.load(openfile)
    for node in node_obj:
        node["graph"] = graph_query_result.inserted_id
        node_query_result = db.node.insert_one(node)
        log.debug("Node %s inserted id : %s ",node["name"],node_query_result.inserted_id)

    print("-----------Create Edge Start-----------")
    # create edge
    with open(edge_file,'r') as openfile:
        edge_obj = json.load(openfile)
    for edge in edge_obj:
        edge_query_result = db.edge.insert_one(edge)
        log.debug("Edge dst %s inserted id : %s ",edge["dst"],edge_query_result.inserted_id)