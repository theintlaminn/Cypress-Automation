import structlog
import json

log = structlog.get_logger()

def remove_all(db):
    removeNodes = ["nd_create_pre_define_cpe","nd_create_pos_case_cpe","nd_update_pre_define_cpe",
               "nd_create_pre_define_ftsbs","nd_create_pos_case_ftsbs","nd_update_pre_define_ftsbs",
               "nd_create_pre_define_otb","nd_create_pos_case_otb","nd_update_pre_define_otb",
               "nd_create_pre_define_ca2","nd_create_pos_case_ca2","nd_update_pre_define_ca2",
               "nd_create_pre_define_ca1","nd_create_pos_case_ca1","nd_update_pre_define_ca1",
               "nd_create_pre_define_olt","nd_create_pos_case_olt","nd_update_pre_define_olt"]
    
    removeGraphs = ["nd_create_pre_define_olt","nd_create_pos_case_olt","nd_update_pre_define_olt"]

    print("-----------Delete All Start-----------")
    # DELETE TEST DATA (one by one)
    with open('cypress.env.json','r') as openfile:
        json_obj = json.load(openfile)
    for node in removeNodes:
        # delete node
        query_result = db.node.delete_one({ "name": json_obj[node] })
        log.debug("%s : is deleted %s count from Node collection.",json_obj[node],query_result.deleted_count)

        # delete edge
        query_result = db.edge.delete_one({"dst":json_obj[node]})
        log.debug("%s : is deleted %s count from Edge collection.",json_obj[node],query_result.deleted_count)

    for graph in removeGraphs:
        query_result = db.graph.delete_one({"name":json_obj[graph]})
        log.debug("%s : is deleted %s count from Graph collection.",json_obj[graph],query_result.deleted_count)
        

    # # Delete all TEST DATA
    # removeNodesName = []
    # # Delete all nodes
    # for node in removeNodes:
    #     removeNodesName.append(json_obj[node])
    # query_result = db.node.delete_many({"name":{"$in":removeNodesName}})
    # log.debug("Total deleted count from Node collection is %s .",query_result.deleted_count)

    # # Delete all edges
    # query_result = db.edge.delete_many({"dst":{"$in":removeNodesName}})
    # log.debug("Total deleted count from Edge collection is %s .",query_result.deleted_count)

    # # Delete all graphs
    # removeGraphsName = []
    # for graph in removeGraphs:
    #     removeGraphsName.append(json_obj[graph])
    # query_result = db.graph.delete_many({"name":{"$in":removeGraphsName}})
    # log.debug("Total deleted count from Node collection is %s .",query_result.deleted_count)



