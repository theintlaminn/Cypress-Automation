// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
import LoginPage from "../../POM/pages/LoginPage";
import LogoutPage from "../../POM/pages/LogoutPage";
const loginPage = new LoginPage();
const logoutPage = new LogoutPage();

Cypress.Commands.add("login", (userName, password) => {
  cy.session([userName, password], () => {
    cy.visit("/");
    loginPage.fillUserName(userName);
    loginPage.fillPassword(password);
    loginPage.clickLoginBtn();
  });
});

Cypress.Commands.add("logout", () => {
  logoutPage.clickLogoutBtn();
  logoutPage.clickLogoutLink();
});
